Minesweeper version 1.0
Release date: 3 May 2019
Made by Trevor Natiuk

Pretty much emulates the processes of the original minesweeper.
- The option "click the face" is a reference to the original Minesweeper, in which clicking the face would start a new game.
- Uncovering an already-uncovered square will also uncover all surrounding covered squares, provided that the value of the square matches the number of surrounding flags.

Other than that, have fun!
Contact me at trevornatiuk@gmail.com for questions, suggestions, or bugs!